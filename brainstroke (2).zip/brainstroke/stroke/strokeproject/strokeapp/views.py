from django.shortcuts import render,redirect
from django.http import HttpRequest,HttpResponse, JsonResponse
import mysql.connector
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from datetime import datetime
from django.contrib import messages
import random
def index(request):
    return redirect('/register')
def register(request):
    #return render(request,'reg.html')
    #return HttpResponse('<h1>Welcome to kits</h1>')
    if(request.method=="POST"):
        email=request.POST['email']
        pwd=request.POST['password']
        uname=request.POST['uname']
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="nanditha"
        )
        mycursor = conn.cursor()
        mycursor.execute("select * from patient where email='"+email+"'")
        result=mycursor.fetchone()
        if(result!=None):
            request.session['email'] = email
            return render(request,"register.html")
        else:
            print("im in post request", request.POST['email'])
            conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="nanditha"
            )
            uname=request.POST['uname']
            email=request.POST['email']
            pwd=request.POST['password']
            mycursor = conn.cursor()
            mycursor.execute("insert into patient(uname,email,pwd) values('"+uname+"','"+email+"','"+pwd+"')")
            conn.commit()    
            return render(request,"login.html",{"status":"invalid credentials"})
    

    elif(request.method=="POST"):
        print("im in post request", request.POST['email'])
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="nanditha"
        )
        uname=request.POST['uname']
        email=request.POST['email']
        pwd=request.POST['password']
        mycursor = conn.cursor()
        mycursor.execute("insert into patient(uname,email,pwd) values('"+uname+"','"+email+"','"+pwd+"')")
        conn.commit()    
        return render(request,'login.html')
        
    else:
        return render(request,'register.html')

def login(request):
    if(request.method=="POST"):
        email=request.POST['email']
        pwd=request.POST['password']
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="nanditha"
        )
        mycursor = conn.cursor()
        mycursor.execute("select * from patient where email='"+email+"' and pwd='"+pwd+"'")
        result=mycursor.fetchone()
        if(result!=None):
            request.session['uname'] = email  
            return render(request,"form.html")
        else:
            
            return render(request,"login.html",{"status":"invalid credentials"})
    else:
        return render(request,'login.html')
    

import pandas as pd
from sklearn.svm import SVC
def classify(file,impacts,outcome,inps):
    data=pd.read_csv(file)
    X=data[impacts]
    Y=data[outcome]
    Y=Y.round()
    clf=SVC(kernel='linear')
    clf.fit(X,Y)
    nx=[inps]
    pred=clf.predict(nx)
    return pred


def predict(request):
    age = request.POST['age']
    gender= request.POST['gender']
    hypertension= request.POST['hypertension']
    heart_disease=request.POST['heart_disease']
    ever_married=request.POST['ever_married']
    work_type=request.POST['work_type']
    Residence_type=request.POST['Residence_type']
    avg_glucose_level=request.POST['avg_glucose_level']
    bmi=request.POST['bmi']
    smoking_status=request.POST['smoking_status']
    pred = classify("D:\stroke\strokeproject/balanced_data_1.csv",['gender','age','hypertension','heart_disease','ever_married','work_type','Residence_type','avg_glucose_level','bmi','smoking_status'],"stroke",[gender,age,hypertension,heart_disease,ever_married,work_type,Residence_type,avg_glucose_level,bmi,smoking_status])
    print(pred[0])
    if pred[0] == 0:
        return render(request,"prediction1.html")
    elif pred[0] == 1:
        return render(request,"prediction2.html")
    else:
        return render(request,"form.html")

        
def logout(request):
    try:
        if('uname' in request.session):
             del request.session["uname"]
    except KeyError:
        pass
    return redirect('login')
def causes(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"causes.html")
     
def symptoms(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"symptoms.html")


def prediction2(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"prediction2.html")

def prediction1(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"prediction1.html")

def form(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"form.html")


def forgotpwd(request):
    if request.method == 'POST':
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="nanditha"
        )
        mycursor = conn.cursor()
        # retrieve post details
        email = request.POST['email']
        mycursor.execute("SELECT pwd FROM patient register WHERE email='" + email + "'")
        result = mycursor.fetchone()
        pwd = str(result[0])
        if result is not None:
            # SMTP server configuration
            smtp_server = 'smtp.gmail.com'
            smtp_port = 587
            smtp_username = 'saichandchinthala@gmail.com'
            # For App Password, enable 2-step verification, then create an app password
            smtp_password = 'rwaa cppa qxol ibwm'
            # Email content
            subject = 'Password recovery'
            body = 'This is a Password recovery email sent from Brain Stroke Prediction. ' \
                   'Your password as per registration is: ' + pwd
            sender_email = 'saichandchinthala@gmail.com'
            receiver_email = email
            # Create a message
            message = MIMEMultipart()
            message['From'] = sender_email
            message['To'] = receiver_email
            message['Subject'] = subject
            message.attach(MIMEText(body, 'plain'))
            # Connect to SMTP server and send the email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(smtp_username, smtp_password)
                server.sendmail(sender_email, receiver_email, message.as_string())
            message = "Password sent to the given email ID"
            return render(request, 'login.html', {'alert_message': message})
        else:
            message = "Please enter the correct email ID"
            return render(request, 'forgotpwd.html', {'alert_message': message})
    else:
        return render(request, 'forgotpwd.html')
def hospital(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"hospital.html")
def karimnagar(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"karimnagar.html")
def warangal(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"warangal.html")
def hyderabad(request):
     if 'uname' not in request.session:
        return redirect('login') 
     return render(request,"hyderabad.html")
    