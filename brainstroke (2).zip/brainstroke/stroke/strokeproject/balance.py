import pandas as pd
import numpy as np

def balance_dataset(file, output_file, target_column, balance_ratio=1.0):
    # Read the original dataset
    data = pd.read_csv(file)

    # Split the data into class 0 and class 1
    class_0 = data[data[target_column] == 0]
    class_1 = data[data[target_column] == 1]

    # Determine the number of samples to keep from each class
    num_samples_class_0 = int(len(class_1) * balance_ratio)
    num_samples_class_1 = len(class_1)

    # Sample random rows from class 0 to balance the dataset
    class_0_balanced = class_0.sample(n=num_samples_class_0, random_state=42)

    # Concatenate the balanced datasets
    balanced_data = pd.concat([class_0_balanced, class_1], ignore_index=True)

    # Save the balanced dataset to a new CSV file
    balanced_data.to_csv(output_file, index=False)

    return balanced_data

# Specify the input file, output file, and target column
input_file = "D:/stroke/strokeproject/stroke2cpy.csv"
output_file = "balanced_data_1.csv"
target_column = "stroke"

# Balance the dataset with a balance ratio of 1.0 (equal number of samples for class 0 and class 1)
balance_ratio = 1.0
balanced_data = balance_dataset(input_file, output_file, target_column, balance_ratio)

# Check the class distribution in the balanced dataset
class_distribution = balanced_data[target_column].value_counts()
print("Balanced Class Distribution:")
print(class_distribution)
